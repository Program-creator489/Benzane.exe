#include <windows.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <mmsystem.h>
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

DWORD xs;
VOID SeedXorshift32(DWORD dwSeed) {
	xs = dwSeed;
}

DWORD Xorshift32() {
	xs ^= xs << 13;
	xs ^= xs << 17;
	xs ^= xs << 5;
	return xs;
}

static ULONGLONG n, r;
int randy( ) { return n = r, n ^= 0x8ebf635bee3c6d25, n ^= n << 5 | n >> 26, n *= 0xf3e05ca5c43e376b, r = n, n & 0x7fffffff; }

typedef union _RGBQUAD {

	COLORREF rgb;
	struct {
		BYTE r;
		BYTE g;
		BYTE b;
		BYTE Reserved;
	};

}_RGBQUAD, * PRGBQUAD;

int red = 0, green = 0, blue = 0;
bool ifblue = false;

COLORREF Hue(int length)
{
	if (red != length) {
		red++;
		if (ifblue)
			return RGB(red, 0, length);
		else
			return RGB(red, 0, 0);
	}
	else if (green != length) {
		green++;
		return RGB(length, green, 0);
	}
	else if (blue != length) {
		blue++;
		return RGB(0, length, blue);
	}
	else {
		red = green = blue = 0;
		ifblue = true;
		return RGB(0, 0, 0);
	}
}

VOID
WINAPI
Initialize( VOID ) {
	HMODULE hModUser32 = LoadLibraryW(L"user32.dll");
	BOOL( WINAPI * SetProcessDPIAware )( VOID ) = ( BOOL ( WINAPI * )( VOID ) ) GetProcAddress ( hModUser32, "SetProcessDPIAware" );
	if ( SetProcessDPIAware )
		SetProcessDPIAware( );
	FreeLibrary( hModUser32 );
}

DWORD 
WINAPI 
wide( LPVOID lpParam ) {

	HDC desk;
	int sw, sh;

	while (1) {
		desk = GetDC(0);
		sw = GetSystemMetrics(0);
		sh = GetSystemMetrics(1);
		StretchBlt(desk, -20, 0, sw + 40, sh, desk, 0, 0, sw, sh, SRCERASE);
		ReleaseDC(0, desk);
		Sleep(4);
	}

	return 0;

}

DWORD 
WINAPI 
polygon( LPVOID lpParam ) {

	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1)
	{
		HDC hdc = GetDC(0);
		HBRUSH brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
		SelectObject(hdc, brush);
		POINT vertices[] =
		{
			{
				rand() % w, rand() % h
			},
			{
				rand() % w, rand() % h
			},
			{
				rand() % w, rand() % h
			}
		};
		Polygon(hdc, vertices, sizeof(vertices) / sizeof(vertices[0]));
		Sleep(10);
		DeleteObject(brush);
		ReleaseDC(0, hdc);
	}

	return 0;

}

DWORD 
WINAPI
MeltingTrain( LPVOID lpParam ) {

	int w = GetSystemMetrics(0);
	int h = GetSystemMetrics(1);
	while (1) {
		HDC hdc = GetDC(0);
		BitBlt(hdc, -30, 0, w, h, hdc, 0, 0, SRCINVERT);
		BitBlt(hdc, w - 30, 0, w, h, hdc, 0, 0, SRCINVERT);
		ReleaseDC(0, hdc);
	}

	return 0;

}

DWORD 
WINAPI 
BlueCheckerBoard( LPVOID lpParam ) {

	HDC hdcScreen = GetDC(0), hdcMem = CreateCompatibleDC(hdcScreen);
	INT w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	BITMAPINFO bmi = { 0 };
	PRGBQUAD rgbScreen = { 0 };
	bmi.bmiHeader.biSize = sizeof(BITMAPINFO);
	bmi.bmiHeader.biBitCount = 32;
	bmi.bmiHeader.biPlanes = 1;
	bmi.bmiHeader.biWidth = w;
	bmi.bmiHeader.biHeight = h;
	HBITMAP hbmTemp = CreateDIBSection(hdcScreen, &bmi, NULL, (void**)&rgbScreen, NULL, NULL);
	SelectObject(hdcMem, hbmTemp);
	for (;;) {
		hdcScreen = GetDC(0);
		BitBlt(hdcMem, 0, 0, w, h, hdcScreen, 0, 0, SRCERASE);
		for (INT i = 0; i < w * h; i++) {
			INT x = i % w, y = i / w;
			rgbScreen[i].rgb += x ^ y;
		}
		BitBlt(hdcScreen, 0, 0, w, h, hdcMem, 0, 0, SRCERASE);
		ReleaseDC(NULL, hdcScreen); DeleteDC(hdcScreen);
	}

	return 0;

}

DWORD 
WINAPI 
ColorBandParty( LPVOID lpParam ) {

	int time = GetTickCount();
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	RGBQUAD* data = (RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCERASE);
		GetBitmapBits(hbm, 4 * h * w, data);
		int v = 0;
		BYTE byte = 0;
		if ((GetTickCount() - time) > 10)
			byte = randy() % 0xff;
		for (int i = 0; w * h > i; ++i) {
			if (!(i % h) && !(randy() % 110))
				v = randy() % 24;
			*((BYTE*)data + 4 * i + v) -= 5;
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCERASE);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}

	return 0;

}

DWORD 
WINAPI 
BltShift( LPVOID lpParam ) {

	HDC desktop = GetDC(NULL);
	int xs = GetSystemMetrics(SM_CXSCREEN);
	int ys = GetSystemMetrics(SM_CYSCREEN);
	while ( TRUE ) {
		desktop = GetDC(NULL);
		BitBlt(desktop, 1, 1, xs, ys, desktop, -2, 2, SRCERASE);
		ReleaseDC(0, desktop);
		Sleep(10);
	}

	return 0;

}

DWORD 
WINAPI 
EraseCubes( LPVOID lpParam ) {

	while (1) {
		HDC hdc = GetDC(NULL);
		int w = GetSystemMetrics(SM_CXSCREEN),
			h = GetSystemMetrics(SM_CYSCREEN);
		StretchBlt(hdc, 10, 10, w - 20, h - 20, hdc, 0, 0, w, h, SRCERASE);
		StretchBlt(hdc, -10, -10, w + 20, h + 20, hdc, 0, 0, w, h, SRCERASE);
		ReleaseDC(NULL, hdc);
	}

	return 0;

}

DWORD 
WINAPI 
textout( LPVOID lpParam ) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
	int signY = 1;
	int signX1 = 1;
	int signY1 = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	LPCWSTR lpText = L"Get Cooked!";
	while (1) {
		HDC hdc = GetDC(0);
		x += incrementor * signX;
		y += incrementor * signY;
		int top_x = 0 + x;
		int top_y = 0 + y;
		SetTextColor(hdc, Hue(239));
		SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
		TextOutW(hdc, top_x, top_y, lpText, wcslen(lpText));
		if (y == GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}

		if (x == GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}

		if (y == 0)
		{
			signY = 1;
		}

		if (x == 0)
		{
			signX = 1;
		}
		Sleep(10);
		ReleaseDC(0, hdc);
	}

	return 0;

}

DWORD 
WINAPI 
textout2( LPVOID lpParam ) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	int signX = 1;
	int signY = 1;
	int signX1 = 1;
	int signY1 = 1;
	int incrementor = 10;
	int x = 10;
	int y = 10;
	LPCWSTR lpText = L"Benzane.exe";
	while (1) {
		HDC hdc = GetDC(0);
		x += incrementor * signX;
		y += incrementor * signY;
		int top_x = 0 + x;
		int top_y = 0 + y;
		SetTextColor(hdc, Hue(239));
		SetBkColor(hdc, RGB(rand() % 255, rand() % 255, rand() % 255));
		TextOutW(hdc, top_x, top_y, lpText, wcslen(lpText));
		if (y == GetSystemMetrics(SM_CYSCREEN))
		{
			signY = -1;
		}

		if (x == GetSystemMetrics(SM_CXSCREEN))
		{
			signX = -1;
		}

		if (y == 0)
		{
			signY = 1;
		}

		if (x == 0)
		{
			signX = 1;
		}
		Sleep(10);
		ReleaseDC(0, hdc);
	}

	return 0;

}

DWORD 
WINAPI 
VintagePixtelize( LPVOID lpParam ) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	_RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCCOPY);
		GetBitmapBits(hbm, w * h * 4, data);
		for (int i = 0; i < w * h; i++) {
			int randPixel = Xorshift32() % w;
			int tempB = GetBValue(data[i].rgb);
			data[i].rgb = RGB(GetBValue(data[randPixel].rgb), GetBValue(data[randPixel].rgb), GetBValue(data[randPixel].rgb));
			data[randPixel].rgb = RGB(tempB, tempB, tempB);
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCCOPY);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}

DWORD WINAPI BetterRGBQuad(LPVOID lpParam) {
	int w = GetSystemMetrics(0), h = GetSystemMetrics(1);
	_RGBQUAD* data = (_RGBQUAD*)VirtualAlloc(0, (w * h + w) * sizeof(_RGBQUAD), MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);
	for (int i = 0;; i++, i %= 3) {
		HDC desk = GetDC(NULL);
		HDC hdcdc = CreateCompatibleDC(desk);
		HBITMAP hbm = CreateBitmap(w, h, 1, 32, data);
		SelectObject(hdcdc, hbm);
		BitBlt(hdcdc, 0, 0, w, h, desk, 0, 0, SRCERASE);
		GetBitmapBits(hbm, w * h * 4, data);
		for (int i = 0; i < w * h; i++) {
			int x = i % w, y = i / h, t = y ^ y | x;
			data[i].rgb = (t & data[i].rgb % RGB(255, 255, 255) ^ x & y);
		}
		SetBitmapBits(hbm, w * h * 4, data);
		BitBlt(desk, 0, 0, w, h, hdcdc, 0, 0, SRCERASE);
		DeleteObject(hbm);
		DeleteObject(hdcdc);
		DeleteObject(desk);
	}
	return 0;
}

DWORD
WINAPI
RedrawDesktop( LPVOID lpParam ) {

	while ( TRUE ) {

		RedrawWindow(0, 0, 0, RDW_INVALIDATE | RDW_ERASE | RDW_ALLCHILDREN | RDW_UPDATENOW);

		Sleep(2000);
	}

	return 0;

}

DWORD 
WINAPI 
GdiThread( LPVOID lpParam ) {

    srand ( (unsigned ) time ( NULL ) );
    HANDLE hCurrent = NULL;

    while ( 1 )
    {
        if ( hCurrent )
        {
            TerminateThread( hCurrent, 0 );
            CloseHandle( hCurrent );
            hCurrent = NULL;
        }

        int choice = rand( ) % 12;
        switch ( choice )
        {
            case 1: hCurrent = CreateThread( NULL, 0, wide, NULL, 0, NULL ); break;
            case 2: hCurrent = CreateThread( NULL, 0, polygon, NULL, 0, NULL ); break;
            case 3: hCurrent = CreateThread( NULL, 0, MeltingTrain, NULL, 0, NULL ); break;
            case 4: hCurrent = CreateThread( NULL, 0, BlueCheckerBoard, NULL, 0, NULL ); break;
            case 5: hCurrent = CreateThread( NULL, 0, ColorBandParty, NULL, 0, NULL ); break;
			case 6: hCurrent = CreateThread( NULL, 0, BltShift, NULL, 0, NULL ); break;     
			case 7: hCurrent = CreateThread( NULL, 0, EraseCubes, NULL, 0, NULL ); break;
			case 8: hCurrent = CreateThread( NULL, 0, textout, NULL, 0, NULL ); break;
			case 9: hCurrent = CreateThread( NULL, 0, textout2, NULL, 0, NULL ); break;
			case 10: hCurrent = CreateThread( NULL, 0, VintagePixtelize, NULL, 0, NULL ); break;
			case 11: hCurrent = CreateThread( NULL, 0, BetterRGBQuad, NULL, 0, NULL ); break;
		
		}

        int delay = ( rand ( ) % 2 ) ? 4000 : 6000;
        Sleep( delay );
    }
    return 0;
}

VOID 
WINAPI 
sound1 ( ) {

	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen ( &hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL );

	char buffer [ 8000 * 30 ] = { };
	for ( DWORD t = 0; t < sizeof ( buffer ); ++t )

		buffer [ t ] = ( char ) ( ( t & 5 * t | t>> 4 ) + ( t | t>> 4 * t<<7 ) ^ t>> 12 );

	WAVEHDR header = { buffer, sizeof( buffer ), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader ( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutWrite ( hWaveOut, &header, sizeof( WAVEHDR ) );

	waveOutUnprepareHeader ( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutClose ( hWaveOut );

}

VOID 
WINAPI 
sound2 ( ) {

	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 32000, 32000, 1, 8, 0 };
	waveOutOpen ( &hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL );

	char buffer [ 32000 * 30 ] = { };
	for ( DWORD t = 0; t < sizeof ( buffer ); ++t )

		buffer[t] = ( char ) ( ( t >> 6 | t << 1) + ( t >> 5 | t << 3 | t >> 3 ) | t >> 2 | t >> 1 | t >> 5 | t >> 9 );

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutWrite(hWaveOut, &header, sizeof(WAVEHDR));

	waveOutUnprepareHeader(hWaveOut, &header, sizeof(WAVEHDR));
	waveOutClose( hWaveOut );

}

VOID 
WINAPI 
sound3 ( ) {

	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen ( &hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL );

	char buffer [ 8000 * 30 ] = { };
	for ( DWORD t = 0; t < sizeof ( buffer ); ++t )

		buffer [ t ] = ( char ) ( t % 25 - ( t >> 2 | 15 * t | t % 227 ) - t >> 3 ) + ( t << 1 );

	WAVEHDR header = { buffer, sizeof ( buffer ), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader ( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutWrite( hWaveOut, &header, sizeof ( WAVEHDR ) );

	waveOutUnprepareHeader ( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutClose ( hWaveOut );

}

VOID 
WINAPI 
sound4 ( ) {

	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen ( &hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL );

	char buffer [ 8000 * 30 ] = { };
	for ( DWORD t = 0; t < sizeof( buffer ); ++t )

		buffer [ t ] = ( char ) ( ( t >> 6 | t << 1 ) + ( t >> 5 | t << 3 | t >> 3) | t >> 2 | t << 1 );

	WAVEHDR header = { buffer, sizeof ( buffer ), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader ( hWaveOut, &header, sizeof( WAVEHDR ) );
	waveOutWrite ( hWaveOut, &header, sizeof ( WAVEHDR ) );

	waveOutUnprepareHeader (hWaveOut, &header, sizeof( WAVEHDR ) );
	waveOutClose ( hWaveOut );

}

VOID 
WINAPI 
sound5 ( ) {

	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 12000, 12000, 1, 8, 0 };
	waveOutOpen ( &hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL );

	char buffer [ 12000 * 30 ] = { };
	for ( DWORD t = 0; t < sizeof ( buffer ); ++t )

		buffer [ t ] = ( char ) ( 9 * t & t >> 4 | 5 * t & t >> 7 | 3 * t & t >> 10 );

	WAVEHDR header = { buffer, sizeof ( buffer ), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader ( hWaveOut, &header, sizeof( WAVEHDR ) );
	waveOutWrite ( hWaveOut, &header, sizeof( WAVEHDR ) );

	waveOutUnprepareHeader ( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutClose ( hWaveOut );

}

VOID 
WINAPI 
sound6 ( ) {

	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen ( &hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL );

	char buffer [ 8000 * 30 ] = { };
	for ( DWORD t = 0; t < sizeof ( buffer ); ++t )

		buffer [ t ] = ( char ) ( ( t ^ t * ( t >> ( t >> 9 & 10 ) & 50) | t * 4 ) );

	WAVEHDR header = { buffer, sizeof( buffer ), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader ( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutWrite ( hWaveOut, &header, sizeof( WAVEHDR ) );

	waveOutUnprepareHeader ( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutClose ( hWaveOut );

}

VOID
WINAPI
sound7 ( ) {

	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen ( &hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL );

	char buffer [ 8000 * 30 ] = { };
	for ( DWORD t = 0; t < sizeof( buffer ); ++t )

		buffer[ t ] = ( char ) ( ( t >> 6 | t << 1 ) + ( 6 ) + 9 * t & t >> 4 | 5 * t & t >> 7 | 3 * t & t >> 10 + ( t >> 5 | t << 3 | t >> 3 ) + ( 6 ) - t << 1 );

	WAVEHDR header = { buffer, sizeof(buffer), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutWrite( hWaveOut, &header, sizeof ( WAVEHDR ) );

	waveOutUnprepareHeader(hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutClose ( hWaveOut );

}

VOID 
WINAPI
sound8() {

	HWAVEOUT hWaveOut = 0;
	WAVEFORMATEX wfx = { WAVE_FORMAT_PCM, 1, 8000, 8000, 1, 8, 0 };
	waveOutOpen ( &hWaveOut, WAVE_MAPPER, &wfx, 0, 0, CALLBACK_NULL );

	char buffer [ 8000 * 30 ] = { };
	for ( DWORD t = 0; t < sizeof ( buffer ); ++t )

		buffer [ t ] = ( char ) ( t >> 6 | t << 1 ) - ( t >> 5 | t << 3 );

	WAVEHDR header = { buffer, sizeof ( buffer ), 0, 0, 0, 0, 0, 0 };
	waveOutPrepareHeader(hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutWrite(hWaveOut, &header, sizeof ( WAVEHDR ) );

	waveOutUnprepareHeader ( hWaveOut, &header, sizeof ( WAVEHDR ) );
	waveOutClose ( hWaveOut );

}

INT
WINAPI
wWinMain(
	_In_ HINSTANCE hInstance,
	_In_opt_ HINSTANCE hPrevInstance,
	_In_ PWSTR pszCmdLine,
	_In_ INT nShowCmd
)
{

	Initialize( );


	if ( MessageBoxW ( 0, L"Benzane.exe, Run?", L"Benzane.exe", MB_YESNO | MB_ICONEXCLAMATION ) == IDNO ) {

		ExitProcess( 0 );

	}

	if ( MessageBoxW ( 0, L"Are you sure?", L"Benzane.exe", MB_YESNO | MB_ICONEXCLAMATION ) == IDNO ) {

		ExitProcess( 0 );

	}

	Sleep( 1000 );

	HANDLE hGdiThread = CreateThread( 0, 0, GdiThread, 0, 0, 0 );
	HANDLE hRedrawThread = CreateThread( 0, 0, RedrawDesktop, 0, 0, 0 );

	sound1( );
	Sleep( 30000 );

	sound2( );
	Sleep( 30000 );

	sound3( );
	Sleep( 30000 );

	sound4( );
	Sleep( 30000 );

	sound5( );
	Sleep( 30000 );

	sound6( );
	Sleep( 30000 );

	sound7( );
	Sleep( 30000 );

	sound8( );
	Sleep( 30000 );

	TerminateThread(hGdiThread, 0);
	CloseHandle(hGdiThread);
	
	TerminateThread( hRedrawThread, 0 );
	CloseHandle( hRedrawThread );

	Sleep( 100 );

	return 0;

}